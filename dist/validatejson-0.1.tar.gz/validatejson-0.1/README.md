# validatejson
This is simple tool to validate JSON payload against the JSON schema
